package Model;

import java.sql.*;

public class Report {
    public String content;
    public String filename;

    public Report(String content, String filename) {
        this.content = content;
        this.filename = filename;
    }
    
    
}
