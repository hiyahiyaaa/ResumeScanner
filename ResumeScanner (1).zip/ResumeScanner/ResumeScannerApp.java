import View.MainUI;

public class ResumeScannerApp {
    public static void main(String[] args) {
        new MainUI();
    }
}

